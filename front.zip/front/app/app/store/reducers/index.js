import {combineReducers} from 'redux';
import {config} from './config';

export const reducer = combineReducers({config});