//import * as ACTIONS from '../actions/Actions';

export const SET_CONFIG ='SET_CONFIG';